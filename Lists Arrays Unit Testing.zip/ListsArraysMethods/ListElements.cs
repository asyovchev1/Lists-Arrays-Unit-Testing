﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace ListsArraysMethods
{
    public class ListElements
    {
        public int SumListElementsByPairs(List<int> input)
        {
            int sum = 0;
            for (int i = 0; i < input.Count / 2; i++)
            {
                sum = sum + input[i] + input[input.Count - 1 - i];
            }

            if (input.Count % 2 != 0)
            {
                sum = sum + input[input.Count / 2];
            }

            return sum;
        }
    }
}

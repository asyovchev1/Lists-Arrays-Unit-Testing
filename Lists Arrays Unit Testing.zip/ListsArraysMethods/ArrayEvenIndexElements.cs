﻿namespace ListsArraysMethods
{
    public class ArrayEvenIndexElements
    {
        public int GetEvenElementsSum(int[] input)
        {
            int sum = 0;

            for (int i = 0; i < input.Length; i++) 
            { 
                if (i % 2 == 0)
                {
                    sum += input[i];
                }
            }

            return sum;
        }
    }
}

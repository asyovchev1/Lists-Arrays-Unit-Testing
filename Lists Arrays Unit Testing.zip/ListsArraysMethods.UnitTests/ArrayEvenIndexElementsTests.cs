namespace ListsArraysMethods.UnitTests
{
    public class ArrayEvenIndexElementsTests
    {
        [Test, Order(1)]
        public void Test_ArrayEvenIndexElementsNoElements()
        {
            //Arrange
            ArrayEvenIndexElements runner = new ArrayEvenIndexElements();
            int[] input = new int[] { };

            //Act
            int result = runner.GetEvenElementsSum(input);

            //Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(2)]
        public void Test_ArrayEvenIndexElementsOneElement()
        {
            //Arrange
            ArrayEvenIndexElements runner = new ArrayEvenIndexElements();
            int[] input = new int[] { 1 };

            //Act
            int result = runner.GetEvenElementsSum(input);

            //Assert
            Assert.That(result, Is.EqualTo(1));
        }

        [Test, Order(3)]
        public void Test_ArrayEvenIndexElementsaAllZeroes()
        {
            //Arrange
            ArrayEvenIndexElements runner = new ArrayEvenIndexElements();
            int[] input = new int[] { 0, 0, 0, 0, 0, 0, 0 };

            //Act
            int result = runner.GetEvenElementsSum(input);

            //Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(4)]
        public void Test_ArrayEvenIndexElementsaAllPositives()
        {
            //Arrange
            ArrayEvenIndexElements runner = new ArrayEvenIndexElements();
            int[] input = new int[] { 3, 6, 2, 1, 12, 6, 8, 222, 4 };

            //Act
            int result = runner.GetEvenElementsSum(input);

            //Assert
            Assert.That(result, Is.EqualTo(29));
        }

        [Test, Order(5)]
        public void Test_ArrayEvenIndexElementsaAllNegatives()
        {
            //Arrange
            ArrayEvenIndexElements runner = new ArrayEvenIndexElements();
            int[] input = new int[] { -4, -1, -11, -3, -6 };

            //Act
            int result = runner.GetEvenElementsSum(input);

            //Assert
            Assert.That(result, Is.EqualTo(-21));
        }

        [Test, Order(6)]
        public void Test_ArrayEvenIndexElementsaMixed()
        {
            //Arrange
            ArrayEvenIndexElements runner = new ArrayEvenIndexElements();
            int[] input = new int[] { -3, 6, 2, -1, 12, -6, 8, 1 };

            //Act
            int result = runner.GetEvenElementsSum(input);

            //Assert
            Assert.That(result, Is.EqualTo(19));
        }
    }
}
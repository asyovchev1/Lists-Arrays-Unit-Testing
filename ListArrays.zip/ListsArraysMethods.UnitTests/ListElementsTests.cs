﻿namespace ListsArraysMethods.UnitTests
{
    public class ListElementsTests
    {
        [Test, Order(1)]
        public void Test_SumListElementsByPairs_NoElements()
        {
            //Arrange
            List<int> input = new List<int> { };

            //Act
            int result = ListElements.SumListElementsByPairs(input);

            //Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(2)]
        public void Test_SumListElementsByPairs_SingleElement()
        {
            //Arrange
            List<int> input = new List<int> { 5 };

            //Act
            int result = ListElements.SumListElementsByPairs(input);

            //Assert
            Assert.That(result, Is.EqualTo(5));
        }

        [Test, Order(3)]
        public void Test_SumListElementsByPairs_OddNumberOfElements()
        {
            //Arrange
            List<int> input = new List<int> { 5, 1, 6 };

            //Act
            int result = ListElements.SumListElementsByPairs(input);

            //Assert
            Assert.That(result, Is.EqualTo(12));
        }

        [Test, Order(4)]
        public void Test_SumListElementsByPairs_EvenNumberOfElements()
        {
            //Arrange
            List<int> input = new List<int> {11, 3, 4, 9 };

            //Act
            int result = ListElements.SumListElementsByPairs(input);

            //Assert
            Assert.That(result, Is.EqualTo(27));
        }

        [Test, Order(5)]
        public void Test_SumListElementsByPairs_AllZeroes()
        {
            //Arrange
            List<int> input = new List<int> { 0, 0, 0, 0, 0 };

            //Act
            int result = ListElements.SumListElementsByPairs(input);

            //Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(6)]
        public void Test_SumListElementsByPairs_AllNegatives()
        {
            //Arrange
            List<int> input = new List<int> { -6, -11, -1, -9, -233, -6, - 7 };

            //Act
            int result = ListElements.SumListElementsByPairs(input);

            //Assert
            Assert.That(result, Is.EqualTo(-273));
        }

        [Test, Order(7)]
        public void Test_SumListElementsByPairs_Mixed()
        {
            //Arrange
            List<int> input = new List<int> { -1, 6, 9, -3, 12, -7 };

            //Act
            int result = ListElements.SumListElementsByPairs(input);

            //Assert
            Assert.That(result, Is.EqualTo(16));
        }
    }
}
